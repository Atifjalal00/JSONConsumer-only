package com.example.jalal;

import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
public class ConsumerListener {

    @KafkaListener(topics = "stringtest", groupId = "group_string2")
    public void consume(String message) {
        System.out.println("Consumed String message: " + message);
    }


    @KafkaListener(topics = "jsontest", groupId = "group_json2",
            containerFactory = "userKafkaListenerFactory")
    public void consumeJson(User user) {
        System.out.println("Consumed JSON Message: " + user);
    }
}
