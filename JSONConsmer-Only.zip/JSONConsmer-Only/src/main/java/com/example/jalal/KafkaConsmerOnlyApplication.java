package com.example.jalal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackageClasses = ConsumerListener.class)
public class KafkaConsmerOnlyApplication {

	public static void main(String[] args) {
		SpringApplication.run(KafkaConsmerOnlyApplication.class, args);
		System.out.println("JSON CONSUMER STARTED");
	}

}
