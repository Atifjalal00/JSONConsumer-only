package com.example.jalal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KafkaConsmerOnlyApplicationTests {

	@Test
	void contextLoads() {
	}

}
